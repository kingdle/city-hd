<div class="row">
    <div class="col-lg-12">
        <div class="ibox float-e-margins">

            <div class="ibox-content">
                指标地图对比，宏观地图
            </div>
        </div>
    </div>
</div>